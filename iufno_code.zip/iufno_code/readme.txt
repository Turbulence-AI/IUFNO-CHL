The code is for the implicit U-Net enhanced Fourier Neural Operator. 
Pytorch and scipy are required for running this code.